---
name: no-amplitude-correction-a
description: Do not apply the global multiplicative amplitude correction A in any ΔΣ fitting workflow — fix it at 1.0.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 16734ae6-b761-45b6-9a6a-da32b218c16b
---

Do not include the global multiplicative amplitude parameter `A` (the
ΔΣ correction historically motivated by spherical-vs-triaxial deficit)
in the destacking ΔΣ fitting workflow. Fix it at 1.0.

**Why:** The user ran two 51-point γ-scans (`gamma_scan_outputs/run_2026-06-12T12-49-51`
with A free under a tight N(0.80, 0.02) prior, and `run_2026-06-13T10-26-14`
with A pinned at 1.0). The recovery is the same to within statistical
scatter — RMS bias 0.310 vs 0.334, ⟨σ_boot⟩ 0.034 vs 0.033 — i.e. A has
negligible effect on γ-recovery. The user decided the parameter isn't worth
keeping.

**How to apply:**
- In `scripts/gamma_scan.py`, the `PRIORS` dict must not contain `'A'`,
  and `PARAM_ORDER` must omit it. `destacking.fitting.run_sampler_combined`
  fixes A at 1.0 when absent from the priors dict (per its docstring).
- Any new fit script or notebook calling `run_sampler_combined` should
  build `priors=` without an `'A'` entry. See [[project-wazp-cmr-unphysical]]
  for the parallel decision about the c-M relation.
- The function `run_sampler_combined` still *accepts* A optionally — leave
  the API alone, but never pass it.
