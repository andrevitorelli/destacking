---
name: ΔΣ plots are always log-log
description: When plotting ΔΣ profiles (per-cluster or stacked), use log scales on BOTH axes — never log-x linear-y.
type: feedback
originSessionId: 16734ae6-b761-45b6-9a6a-da32b218c16b
---
ΔΣ (weak-lensing surface mass density contrast) profile plots must use `set_xscale('log')` AND `set_yscale('log')` — log-log, never log-linear.

**Why:** ΔΣ spans 1–2 orders of magnitude across the radial range of interest (a few × 0.1 to a few × 100 M☉/pc²) and is positive in the cluster regime. Linear y-axis crushes the inner profile (where the signal is strongest and most diagnostic for concentration/miscentering) into a tiny bottom strip while wasting space on near-zero outer bins. Log y-axis preserves the power-law shape and makes radius-dependent biases visible by eye. This is the standard convention in cluster weak-lensing literature.

**How to apply:**
- Any ΔΣ vs R plot — including per-cluster profiles, stacked profiles, best-fit-model overlays, residual-comparison plots in linear-Δ form. Cross-shear (ξₓ) is *not* covered by this rule (it crosses zero by construction).
- Drop the `axhline(0)` reference line when switching to log y — it doesn't render.
- For overlays with stochastic negative outliers (single-cluster scatter), let matplotlib drop them; don't switch to `symlog` unless explicitly requested.
- Apply to current and future ΔΣ plots without being asked.
