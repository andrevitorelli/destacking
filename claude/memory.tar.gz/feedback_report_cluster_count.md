---
name: Always report N_clusters alongside stacked-fit results and on ΔΣ plots
description: When stacked fits are printed (sampler progress, posterior summaries) and when stacked ΔΣ data points are plotted, the number of clusters in each stack must be visible.
type: feedback
originSessionId: 16734ae6-b761-45b6-9a6a-da32b218c16b
---
**Print path.** Anywhere a per-stack fit result is logged from a sampler (nautilus, emcee, etc.), include the per-stack cluster count alongside the parameter values. Examples of what to print:

```python
print(f'{name}: N={n_stacked:,}  logM={mean["log_M"]:.3f}±{sigma:.3f}  ...')
```

**Plot path.** On every stack-level plot — whether it's a ΔΣ vs R profile, a residual plot, a posterior diagnostic — the legend or panel label must show N for that stack. For panel grids with one legend entry per stack: append `N={n_stacked:,}` to the existing label. For per-stack diagnostic figures, put it in the title.

**Why:** N is the dominant determinant of whether a stacked result is statistically meaningful. A 3-cluster stack at α=2.2 and a 1000-cluster stack at α=1.0 are completely different epistemic claims; without N the reader can't weight them. We have a separate rule that N<10 stacks are excluded from downstream fits — but the plots and prints should still show N so the reader can apply their own threshold and spot outliers driven by sparse cells.

**How to apply:**
- Whenever you add a new stacking notebook, treat the per-stack N as a mandatory display field, not optional.
- When updating an existing stack plot or print, audit it for missing N and add it.
- This is in addition to (not instead of) reporting fit-parameter values, σ, and bin coordinates.
