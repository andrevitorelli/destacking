---
name: wazp-desy3-alpha-cm-anomaly
description: "CLOSED 2026-07-26 (user: 'settled this definitively') — WaZP+DES-Y3 mass-concentration slope anomaly was a joint-fit boost-correction bug + a degenerate covariance-floor bug + comparing against the wrong theory curve. See [[project_wazp_desy3_root_cause_hypotheses]] and [[project_bootstrap_covariance_floor_bug]] for the resolution; this file is the original problem statement, kept for history."
metadata: 
  node_type: memory
  type: project
  originSessionId: 16734ae6-b761-45b6-9a6a-da32b218c16b
---

The real WaZP-cluster + DES-Y3-metacal analysis finds the mass-concentration
relation's mass slope (`alpha_cm` / `alpha`) consistent with **zero** in
every measurement made so far, via two independent methods:

- Joint per-cluster (destacking) fit (`scripts/gamma_scan_outputs/run_2026-07-23T15-34-36`,
  50 bootstraps, all converged): `alpha_cm = 0.029^{+0.113}_{-0.111}` (99% CL range).
- Independent stacked/binned cross-check (`scripts/wazp_stacked_analysis.py`
  + `notebooks/wazp_stacked_plots.ipynb`, 24/24 NFW fits converged): low-Δm
  group `alpha = -0.04 ± 0.15`, high-Δm group `alpha = +0.04 ± 0.12`.

**Why this is the anomaly (corrected framing, 2026-07-24 — an earlier version
of this note wrongly framed the issue as "alpha_cm incompatible with zero";
it is the opposite):** established mass-concentration relations (Dutton &
Maccio 2014, Diemer & Joyce 2019, overlaid as theory curves in the stacked
c-M plot) predict a **clearly negative** slope — concentration decreasing
with mass, roughly −0.1 to −0.15 dex over the fitted mass range. Both
independent pipelines here instead land on a slope compatible with zero.
Reproducing the same wrong (null, not negative) result across two very
different fitting methodologies — one continuous joint likelihood over
individual clusters, one traditional stack-bin-and-fit — makes it unlikely
to be a bug specific to either pipeline. It points instead to a
data/measurement problem, consistent with [[project_wazp_cmr_unphysical]]
(prior WaZP work already found unphysical stack-level concentrations from
this same cluster/shear combination, suspected DES-Y3 high-shear
calibration).

**CLOSED, 2026-07-26:** the user explicitly declared this settled
("close the investigation of the anomalous fit... we have settled this
definitively"). Resolution: (1) the joint fit had no boost/membership-
dilution correction at all — fixed by fitting a boost(R) model per stack
and applying it per-cluster via stack membership; (2) a real bug in
`xlensing.data.bootstrap_signal`'s covariance estimator could return an
implausibly tiny variance for low-galaxy-count inner bins, letting one
cluster dominate the whole-sample likelihood — fixed with a physically
motivated shot-noise variance floor; (3) the "anomaly" was partly a bad
point of comparison — Dutton & Maccio (2014) assumes a pure power law,
but Diemer & Joyce (2019) is non-monotonic over this sample's mass range
and, weighted by each cluster's actual Fisher information (not naive
cluster count), predicts a slope near zero, not clearly negative. With
both bugs fixed, the joint fit's `alpha_cm=+0.076 (+0.075/-0.071)` (6-bin,
50/50 converged bootstraps) is consistent with the correctly-computed
theoretical expectation. Full writeup with equations and figures:
`reports/2026-07-26_boost_factors_variance_floor_alpha_cm.tex`. Do not
reopen this investigation or re-litigate the anomaly unless the user
raises new evidence — treat `alpha_cm` from this WaZP+DES-Y3 combination
(boost- and floor-corrected, `gamma_scan_outputs/wazp_real_data_floor6`)
as a resolved, physically reasonable measurement.
