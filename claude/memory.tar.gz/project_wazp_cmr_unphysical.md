---
name: WaZP c-M relation is unphysical
description: The mass-concentration relation extracted from the WaZP stacked NFW fits in wazp_mass_richness_by_delta_m.ipynb (and any sibling notebook) is unphysical; the user suspects DES Y3 shear-calibration issues at high shear.
type: project
originSessionId: 16734ae6-b761-45b6-9a6a-da32b218c16b
---
The mass-concentration relation produced in `notebooks/wazp_mass_richness_by_delta_m.ipynb` §10 (and any sibling notebook that fits a c-M from the stack-level $(M, C)$ posteriors) is **unphysical** as of 2026-06-04.

**Why:** Likely cause is shear-calibration issues in DES Y3 at higher shear (inner cluster radii). The boost-factor correction and the NFW + miscentering model do not absorb whatever residual is biasing the inner-bin ΔΣ, which is where $C$ is constrained.

**How to apply:**
- Don't treat the per-Δm-group c-M slope/normalisation as a physical result. The plot and the joint regression are valid as a diagnostic of what the current pipeline produces, not as a claim about cluster concentrations.
- The downstream M-λ relation is a separate measurement and is **not** invalidated by this — the c-M sub-section is the one to discount.
- The user is aware and will revisit later; do not redo or "improve" the c-M fit unprompted.
- If a new notebook is built that fits c-M from stack-level NFW posteriors, carry this caveat into the markdown.
