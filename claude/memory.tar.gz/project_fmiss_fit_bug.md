---
name: fmiss-fit-mismatch-bug
description: Fits assumed 36% miscentered signal even for centered sims — caused the +10% multiplicative γ bias; fixed 2026-07-17
metadata: 
  node_type: memory
  type: project
  originSessionId: 16734ae6-b761-45b6-9a6a-da32b218c16b
---

The destacking fit model set FMISS = 1 − f_cen = 0.36 unconditionally, so every `miscentering: false` run was FIT with a spuriously miscentered model against perfectly centered data. Verified as the cause of the +10.7% ± 1.8% multiplicative γ recovery bias in the high-SNR test (slope 1.107 → 0.973 ± 0.018 after fixing only this, refitting identical checkpoints; annulus-averaged model evaluation was separately tested and changed nothing).

**Why:** invalidates the FIT results (not the simulations) of all `miscentering: false` runs before 2026-07-17 — the DES/LSST spherical control cells of the 2×2 matrix and the high-SNR spherical/triaxial grids. Miscentering-on runs were always consistent and are unaffected.

**How to apply:** fixed in gamma_inference.py — fit-model miscentering is now explicit config (`fit_fmiss`, `fit_sigma_off_mpc_h`), defaulting to the simulation truth (1−f_cen when miscentering on, 0 when off). Pre-fix centered-sim results needing re-quoting can be refit cheaply in inference-only mode on their existing checkpoints. Related: [[metacal-response-sim-bug]], [[lsst-production-plan]].
