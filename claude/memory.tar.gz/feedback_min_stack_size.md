---
name: Minimum stack size for downstream fits is 10 clusters
description: When stacking clusters in (z, richness, Δm, ...) bins, compute the signal for all stacks but exclude any with fewer than 10 clusters from any fit of relations (M-λ, M-z, M-Δm, etc.).
type: feedback
originSessionId: 16734ae6-b761-45b6-9a6a-da32b218c16b
---
For WaZP-style stacked weak-lensing analyses on the destacking project:

- **Compute the signal for every stack** regardless of population (it's cheap to add to the pipeline and shows whether sparsely-populated cells are inhabited at all).
- **Exclude stacks with N < 10 clusters from every fit of a downstream relation** — M–λ power law, per-z 1D fits, joint M(λ, z) fit, Δm-split comparisons, mass–redshift trends, etc.

**Why:** With fewer than 10 clusters, the bootstrap covariance in `xlensing.data.stacked_signal` is noisy, the NFW + miscentering fit is prior-dominated, and the fitted log M can run away to the prior edge (we saw this with z2_ng5 at N=2 giving log M ≈ 15.94 with C and F_miss pegging the boundaries; including it in a joint fit swung β from +3.1 to −1.7). The high-leverage (and high-uncertainty) point dominates a least-squares regression weighted by 1/σ², and the σ from a runaway fit is artificially small. N≥10 is the rule of thumb that keeps the bootstrap covariance well-defined and the fit out of prior-edge runaway.

**How to apply:**
- When writing a stacking notebook, build the stacks for all cells but track the per-stack N alongside the fit results.
- The downstream regression cell should filter on `n_stacked ≥ 10` (or equivalently mask with `keep = N >= 10`) before building the design matrix and weights.
- Don't silently drop low-N stacks — print which ones were excluded and how many clusters they had.
- This is in addition to dropping cells where the nautilus fit itself failed.
