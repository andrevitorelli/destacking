---
name: Pipeline notebooks need a USE_CACHE toggle
description: Long-running stacking/fitting notebooks must expose a single boolean (default True) that bypasses every cache-load branch, so a stale intermediate cannot silently shortcut a re-run.
type: feedback
originSessionId: 16734ae6-b761-45b6-9a6a-da32b218c16b
---
In notebooks that persist intermediates to `notebooks/data/*.pkl` or `*.npz` and re-load them at the top of cells, there must be a single config variable that overrides every cache-load branch:

```python
USE_CACHE = True   # set to False to force a clean rebuild of every intermediate
```

Apply it by gating every existence check:

```python
if os.path.exists(CACHE) and USE_CACHE:
    ...
else:
    # rebuild from scratch (or, for fit-resume caches, start with empty dict)
```

**Why:** A user re-runs a notebook expecting to recompute because they changed an input upstream (binning, filtered catalog, model code), but the cache pickle is still on disk from the prior parameters, so the new run silently uses stale data. The bug is hard to spot because cell outputs look plausible. The fastest path to a clean recompute is one toggle at the top of the notebook, rather than asking the user to remember which files to `rm -f` first.

**How to apply:**
- Define `USE_CACHE = True` in the same config cell as `NBOOT`, `NWORKERS`, etc.
- Audit every notebook for `if os.path.exists(...):` and add `and USE_CACHE`.
- This applies even to the heaviest pre-filter caches (291 GB scan → 7 GB npz) — the user owns the trade-off and the cost is one log line announcing the rebuild.
- For fit-resume caches (`FITS_PKL`), `USE_CACHE = False` means start with an empty dict rather than skip loading; downstream "resume from disk" logic must respect the toggle, not just the file's existence.
