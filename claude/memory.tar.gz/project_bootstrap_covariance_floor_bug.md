---
name: bootstrap-covariance-floor-bug
description: "xlensing.data.bootstrap_signal could return implausibly tiny (near-zero) per-bin ΔΣ variance for bins with only 2-3 galaxies, letting a single cluster dominate/destroy the entire 15,967-cluster WaZP+DES-Y3 joint likelihood once r_min_fit=0 exposed those bins. FIXED 2026-07-25 with a sigma_e shot-noise variance floor."
metadata:
  node_type: memory
  type: project
  originSessionId: 16734ae6-b761-45b6-9a6a-da32b218c16b
---

Found while testing hypothesis 2 in [[project_wazp_desy3_root_cause_hypotheses]]:
setting `r_min_fit: 0.0` (even after masking mean-value "wild outliers" with
`wild_outlier_mask`) still produced a completely collapsed, non-converged
nautilus posterior (N_eff=1, huge negative but finite log Z, all marginal KL
NaN).

**Root cause:** `xlensing.data.bootstrap_signal`'s galaxy-level bootstrap
resamples the WHOLE source catalog and evaluates a weighted-ratio ΔΣ
estimator per draw. With only 2-3 galaxies physically present in a bin
(typical for the innermost 1-2 radial bins at DES-Y3 density), if those few
galaxies happen to give similar individual ΔΣ estimates, the ratio barely
moves across resamples regardless of galaxy multiplicity — collapsing the
bootstrap variance toward zero even though the true shot-noise uncertainty
is enormous. The function's existing safeguard (`pos_var = diag(cov_t) > 0`,
meant to catch "single repeated galaxy") only rejects EXACT zero, not this
near-zero case.

Quantified on the real WaZP+DES-Y3 checkpoint (15,967 clusters × 8 bins,
`gamma_scan_outputs/wazp_real_data`): only 8 (cluster, bin) entries had
sqrt(var) < 5 Msun/pc^2 — rare, but catastrophic. Cluster 14428, bin 0
(R=0.158 Mpc): raw ΔΣ=1554, var=0.338 (every sibling bin of the same
cluster: var~1e4-1e5). Since bootstrap draws ~10,000 unique clusters with
replacement from the full 15,967 each fit, at least one of these 8
pathological clusters is essentially guaranteed to appear in every
bootstrap — and once it does, its chi^2 alone (residual^2/tiny-variance,
~7 million for cluster 14428) dwarfs the sum over all other clusters
combined (~98% of the total). This, not a "hard science" data-quality
issue, was why r_min_fit=0 collapsed.

**The physical floor:** for the estimator's actual weighting (inverse
Sigma_crit^2), the shot-noise-only variance is
`sigma_e^2 / sum((1+M)*W/Sigma_crit^2)` over the bin's galaxies — derivable
by error propagation, and it reduces to the familiar
`Sigma_crit^2 * sigma_e^2 / N` for N equal-weight galaxies at equal
Sigma_crit. Computed with sigma_e=0.27 (DES-Y3 metacal per-component
ellipticity dispersion) across the sample's actual z_l/z_s range, the floor
sits at var ~1.2e5-1.5e6 for N=1-3 galaxies — the pathological entries
(var 0.2-5) were 6-7 orders of magnitude below even the N=1 floor, ruling
out "just unlucky with few galaxies" and confirming it's an estimator
artifact.

**Fix, implemented and tested 2026-07-25:**
- `xlensing.data.bootstrap_signal` gained `sigma_e`/`floor_rmax` params
  (default None/None = old behaviour unchanged). When `sigma_e` is set,
  floors each bin's variance (both tangential and cross component) at the
  shot-noise lower bound, computed from that bin's actual per-galaxy
  weights/Sigma_crit (reuses `K_b.sum()`, already computed internally) —
  applied only to bins below `floor_rmax`, before the existing
  `pos_var > 0` degenerate-bin check. Tests: `xlensing/tests/test_data.py`
  (`test_bootstrap_signal_floors_degenerate_inner_bin`,
  `test_bootstrap_signal_floor_rmax_restricts_to_inner_bins`,
  `test_bootstrap_signal_no_sigma_e_unchanged`) — all pass; full xlensing
  suite otherwise unaffected (8 pre-existing, unrelated failures in
  `single_cluster`/`stacked_signal` tests confirmed present on `claude`
  branch before this change too, not caused by it).
- `destacking/scripts/prepare_real_data.py`: new `sigma_e`/`floor_rmax`
  YAML config keys threaded through to the `bootstrap_signal` call in
  `_measure_cluster`.
- New config `wazp_desy3_real_data_floor.yaml` (sigma_e=0.27,
  floor_rmax=0.5, matching the old r_min_fit default — i.e. only floors
  bins that r_min_fit=0 newly exposes) → full remeasurement written to
  `gamma_scan_outputs/wazp_real_data_floor/` (separate dir, original
  `wazp_real_data` checkpoint preserved). Verified: 0/15,967 clusters have
  any sqrt(var)<5 entry post-fix (was 8). Direct A/B on 5 real clusters in
  one process confirmed the floor changes ONLY the pathological entries
  (cluster 14428 bin 0: 0.42 -> 17,796) and leaves every other bin/cluster/
  mean-ΔΣ value bit-identical.
- At the prior-mean parameter point on the fixed+boost-corrected checkpoint
  with r_min_fit=0: total chi^2 across 15,925 clusters dropped from
  7,177,229 to 102,461 (70x), mean chi^2/cluster ~6.4 (sane), worst-10
  clusters now only 2.8% of total chi^2 (was 98.7% from one cluster alone).
- `wazp_desy3_inference_boost_floor.yaml`: r_min_fit=0, boosts on,
  wild_outlier_mask OFF (that value-range mask was a stopgap for the same
  symptom this properly fixes — no longer needed, and might discard
  genuinely-large-but-real ΔΣ now that its uncertainty is trustworthy),
  same Dutton-Maccio-centred alpha_cm prior as the prior boost run. Full
  50-bootstrap run completed 2026-07-25 on the 8-bin checkpoint: combined
  alpha_cm = +0.116 +0.056/-0.053 (8 pooled bootstraps at the time of the
  writeup). A 6-bin variant (`wazp_desy3_real_data_floor6.yaml`,
  log_inner_radius=-0.6 instead of -0.8 — wider/fewer bins, more galaxies
  per bin) ran the full 50/50 bootstraps to completion 2026-07-26:
  combined alpha_cm = +0.076 +0.075/-0.071 (1,355,832 pooled samples,
  joint KL 22.13 nats) — still positive but ~1sigma from zero, closer to
  zero than the 8-bin result. Both are now the reference converged results
  for hypothesis 2, superseding all earlier collapsed/pathological attempts.

**wild_outlier_mask found to be statistically INVALID, 2026-07-26 — do not
use it, even as a supplement to the floor:** re-tested it on top of the
already-working 6-bin+floor+boost setup (`wazp_desy3_inference_boost_floor6_wildmask.yaml`,
5-bootstrap check) out of curiosity. bootstrap_000 gave wildly different,
extreme results vs. every one of the 63 unmasked bootstraps seen across
both floor runs: alpha_cm=-0.478 (vs the usual -0.05 to +0.20 range) and
c0=+24.7 (vs the usual ~4-6). Diagnosis (user, immediate): the mask's
range was `wild_outlier_min: 0.0` to `wild_outlier_max: 10000.0` —
ONE-SIDED. Per-cluster ΔΣ noise in these bins is large and straddles zero
symmetrically (see the >=38% ΔΣ<=0 fraction noted even in well-sampled
outer bins); truncating only the negative tail while keeping the positive
one systematically inflates the mean of the surviving sample in exactly
the bins the mask touches (R<0.5 Mpc) — manufacturing a fake excess inner
signal that then forces the fit toward an extreme high-concentration,
steep-negative-slope solution to explain it. This is a selection-bias
artifact of the mask itself, not a data-quality finding. Killed
immediately on user diagnosis. **Corrected to a genuinely two-sided range
(`wild_outlier_min: -10000.0`) for any future retest** — the original
`0.0` lower bound was a mistake carried over from when "wild outlier" was
being conflated with "any negative value" during the initial diagnosis
turn, rather than "implausible magnitude regardless of sign".

**How to apply:** if `xlensing.data.bootstrap_signal` is used anywhere else
in this project (or a future LSST-density run) with very few galaxies per
bin, consider whether `sigma_e`/`floor_rmax` should be set — the failure
mode is silent (a plausible-looking but wrong tiny variance, not a crash)
until it manifests as sampler collapse. The floor is a lower bound only;
it never lowers an already-larger genuine bootstrap variance.
