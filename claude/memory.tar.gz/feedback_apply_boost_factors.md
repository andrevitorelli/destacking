---
name: xlensing.data.stacked_signal applies the boost internally
description: stacked_signal returns boost-corrected ΔΣ and a covariance that already includes boost uncertainty via joint cluster bootstrap; the caller no longer multiplies by boost manually.
type: feedback
originSessionId: 16734ae6-b761-45b6-9a6a-da32b218c16b
---
`xlensing.data.stacked_signal(bkgs, bin_limits, Nboot)` now returns a 6-tuple
```
(sigmas, boosts, boosts_cov, sigmas_cov, xigmas, xigmas_cov)
```
where:

- `sigmas` is the **boost-corrected** ΔΣ — mean of `B(R) · ΔΣ_raw(R)` across the cluster-bootstrap iterations.
- `sigmas_cov` is the covariance of the boost-corrected ΔΣ, computed from `np.cov(B_boot * ΔΣ_boot)`. Because `B` and `ΔΣ` are drawn from the **same** resample indices, this covariance captures the boost uncertainty, the ΔΣ uncertainty, and their cross-correlation, with no further propagation needed in the caller.
- `boosts` and `boosts_cov` are the bootstrapped boost factor and its covariance, useful for diagnostic plots.
- `xigmas` / `xigmas_cov` are the cross-shear counterparts (also boost-corrected for consistency).

**Why:** the previous API returned a deterministic boost and an uncorrected ΔΣ, leaving the caller to multiply (`boost * ΔΣ`) and to propagate the boost error by hand. With the boost now bootstrapped jointly with ΔΣ inside `stacked_signal`, the function delivers a single self-consistent boost-corrected signal and its full covariance.

**How to apply:**

```python
sigmas, boosts, boosts_cov, sigmas_cov, xigmas, xigmas_cov = (
    xlensing.data.stacked_signal(bkgs, BINS_LIMS, NBOOT)
)
# sigmas / sigmas_cov are ready to feed the likelihood as-is.
# Use boosts / boosts_cov for diagnostic plots (with errorbar from sqrt(diag(boosts_cov))).
```

**Sanity check:** `boosts[-1]` should be ≈ 1 (no cluster contamination far from the cluster). Its bootstrap error `sqrt(boosts_cov[-1, -1])` should be small relative to `boosts[-1]`. The stacking-notebook print line emits e.g. `B_outer=0.998±0.012`; emit a warning if the median outer-bin boost lies outside [0.85, 1.15].

**Do NOT** post-multiply `sigmas` by `boosts` — it's already applied. Doing so a second time biases the signal high and gives a wrong covariance.
