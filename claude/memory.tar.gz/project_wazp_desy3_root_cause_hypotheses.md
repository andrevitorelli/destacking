---
name: wazp-desy3-root-cause-hypotheses
description: "CLOSED 2026-07-26 (user: 'settled this definitively', do not reopen) — WaZP+DES-Y3 mass-concentration-slope anomaly fixed by the boost correction + variance floor (see [[project_bootstrap_covariance_floor_bug]]) plus comparing against a Fisher-information-weighted Diemer19 prediction (~0) instead of a naive Dutton-Maccio number (-0.088) or count-weighted average — fitted alpha_cm=+0.076 is not anomalous. Full writeup: reports/2026-07-26_boost_factors_variance_floor_alpha_cm.tex. Hypotheses 1 (foreground) and 3 (WaZP finder) never fully resolved individually but are moot now that the anomaly itself is explained."
metadata:
  node_type: memory
  type: project
  originSessionId: 16734ae6-b761-45b6-9a6a-da32b218c16b
---

Given [[project_wazp_desy3_alpha_cm_anomaly]] (mass-concentration slope
compatible with zero — or, per hypothesis-1 testing below, consistently
positive — when literature predicts clearly negative), the user's three
leading suspicions as of 2026-07-24, to guide investigation:

1. **Foreground contamination survives the boost correction.** Residual
   foreground/cluster-member galaxies misclassified as background sources
   could be diluting/biasing the inner-radius signal — and for the JOINT
   fit specifically this is not "surviving the boost correction," it's
   entirely UNCORRECTED: `prepare_real_data.py` deliberately uses
   `xlensing.data.bootstrap_signal`, NOT `single_cluster`, so the joint
   fit's data vector has no boost applied at all (matches the boost-free
   NFW model it fits — see the module docstring). The stacked cross-check
   does apply boost (`stacked_signal`), so the two pipelines are not
   equally exposed to this.

   **Tested 2026-07-24, result inconclusive — the test was confounded,
   NOT a clean disproof:** background-galaxy selection was exposed as a
   caller-side, swappable control (`destacking.data.select_background`,
   `BACKGROUND_SELECTION_STRATEGIES["margin"]`; xlensing itself no longer
   filters by redshift internally). Tightened the selection margin from
   the old default (factor=1.1) to factor=1.2 and reran both pipelines:
     - Stacked cross-check (`wazp_stacked_analysis.py`, `RUN_TAG="_f1.2"`):
       c-M slope moved only slightly (low Δm: -0.036→-0.044, high Δm:
       +0.044→-0.031) — both groups stayed consistent with zero, shift
       well within the ~0.12-0.17 statistical uncertainty.
     - Joint fit (`wazp_desy3_inference_f1.2.yaml`, data from
       `prepare_real_data_f1.2.yaml`): user stopped the run after 3/50
       bootstraps because `alpha_cm` was **consistently positive** across
       all three (+0.091, +0.075, +0.111) — if anything *further* from
       the expected negative slope than the factor=1.1 baseline's
       combined-posterior result (+0.029).

   **Why the user does not consider this a clean test of hypothesis 1**
   (2026-07-24): tightening the redshift margin removes more sources from
   the INNER radii specifically (where photo-z-scattered contaminants
   concentrate), shrinking the sample exactly where the boost correction
   would normally matter most. For the joint fit — which has NO boost
   correction at all — a smaller inner-radius sample does not obviously
   reduce the contamination fraction (true cluster members with large
   photo-z scatter can still pass a stricter cut, while genuine background
   galaxies with modest scatter get needlessly excluded) and may worsen
   the noise-to-contamination balance in exactly the bins that constrain
   concentration. So the factor=1.2 result moving the wrong way does not
   rule out foreground contamination — it may just mean this particular
   knob (redshift margin alone) is not an effective or clean lever on it,
   especially for the un-boosted joint fit.

2. **`r_min_fit` excludes the scale radius.** ~~The fit's minimum radius
   cut may be removing exactly the inner region where the NFW scale
   radius r_s lives... independent of any data-quality issue.~~

   **Tested 2026-07-25, NOT confirmed — the inner bins turn out to be
   genuinely unusable, not just conservatively excluded:** set
   `r_min_fit: 0.0` (was 0.5) in `wazp_desy3_inference_boost.yaml` (with
   the boost correction and Dutton-Maccio-centred alpha_cm prior from the
   informative-prior test still active) and relaunched. bootstrap_000 hit
   the full 7200s timeout with a completely collapsed, non-converged
   posterior (N_eff=1, every marginal KL NaN, gamma pinned at an extreme
   +0.91). Investigated the real checkpoint
   (`gamma_scan_outputs/wazp_real_data`) directly: per-bin finite fraction
   across the 8 radii is 0.379, 0.662, 0.897, 0.984, 0.994, 0.995, 0.996,
   0.997 (innermost to outermost) — the majority of clusters have NO
   measurement at all in the innermost 1-2 bins (too few background
   sources in that tiny inner annulus for `bootstrap_signal` to produce a
   finite estimate), and even the minority that DO have a finite value
   there include wild unphysical outliers (bin 0: -3.5M to +433k
   M_sun/pc^2; sensible ΔΣ is O(1-1000)). The old `r_min_fit=0.5` default
   sits almost exactly at the point (bin index 3, R=0.631 Mpc) where
   finite fraction jumps to ~98% and stabilizes — it was never an
   arbitrary cut discarding wanted scale-radius information, it tracks a
   real, sharp falloff in per-cluster measurement reliability at small R
   for this survey depth. Killed the run rather than let 49 more
   bootstraps hit the same wall.

   **Correction (2026-07-25) — hypothesis 2 substantially DOES hold, in a
   more serious form than first stated:** the user pointed to
   `notebooks/observability_of_concentrations.ipynb` and the fact that
   the NFW scale radius r_s itself sits inside (or right at the edge of)
   both the r_min_fit=0.5 cut AND the bad-data zone, for most of the
   sample. Quantified via `xlensing.model.r_vir_m` +
   `colossus.halo.concentration` (diemer19) and the pipeline's own
   `destacking.relations.mass_lambda_McClintock18` at z=0.35, across the
   WaZP sample's actual richness range (richness_min=25, most of the
   sample concentrated at low richness):
     lambda=25  (most populated bin): log10(M)=14.21  r_s=0.287 Mpc
     lambda=40:                       log10(M)=14.49  r_s=0.368 Mpc
     lambda=60:                       log10(M)=14.73  r_s=0.447 Mpc
     lambda=100:                      log10(M)=15.03  r_s=0.552 Mpc
     lambda=150 (sparse tail):        log10(M)=15.27  r_s=0.631 Mpc
   For the bulk of the sample (richness 25-60, which dominates cluster
   counts by 10-15x over the high-richness tail), r_s = 0.29-0.45 Mpc —
   inside bins 0-2 (R=0.16, 0.25, 0.40 Mpc), i.e. exactly the region that
   is EITHER excluded by r_min_fit=0.5 OR catastrophically bad data
   (finite fraction 38-90%) if r_min_fit is relaxed. There is essentially
   no radius range in this dataset, for most of the sample, with both
   usable data quality and real sensitivity to concentration.

   **Implication:** this may not be fixable by prior tuning (the alpha_cm
   informative-prior test), the boost correction, or background-selection
   tightening (hypothesis 1) at all — none of those can manufacture
   information the data physically does not contain in the
   concentration-sensitive radius range. Ties back to
   [[project_lsst_production_plan]]: DES-like source density was already
   known to be "information-poor by design" for this kind of measurement;
   this finding gives the precise quantitative mechanism (r_s falls in
   the unmeasurable inner region for typical cluster masses at this
   density) rather than just "noisier in general."

   **Reframing, 2026-07-25 (user decision):** the user no longer treats
   this as necessarily a paper-blocking problem to fix on the real WaZP
   data — it may just be a correct finding to report, since the real
   analysis is framed as prep for a future LSST run. Chosen path forward
   (not yet started): (1) reproduce the same plots/diagnostics with
   SIMULATED clusters at the SAME galaxy density as the real WaZP+DES-Y3
   data used here, to check the sim pipeline reproduces the same
   r_s-unmeasurability behaviour seen in real data; then (2) rerun the
   same simulation at LSST-like galaxy density and see whether
   concentration becomes measurable / alpha_cm recovers the expected
   negative slope. This directly operationalizes
   [[project_lsst_production_plan]]'s "DES-like is information-poor by
   design, LSST-like is the production target" — this hypothesis-2 finding
   is the reason why, and the two-stage sim comparison is the planned
   proof.

   **Resolution, 2026-07-26 — investigation concluded ("that's it, we
   found it"):** two real pipeline bugs fixed the joint fit's numerical
   pathology (see [[project_bootstrap_covariance_floor_bug]] for the
   variance floor, and the boost-factor-fitting work described there
   too), and the "anomaly" itself was largely a bad point of comparison.
   Comparing the fitted alpha_cm against a single Dutton-Maccio (2014)
   number silently assumes (a) the c-M relation is a pure power law
   across the sample's mass range, and (b) every cluster is equally
   informative. Neither holds: the more recent Diemer & Joyce (2019)
   model is non-monotonic (minimum near log10(M)~14.7 for this sample),
   and — this took two rounds of correction — a naive comparison must
   also account for HOW the sample should be weighted:
     - Naive log-uniform grid, fixed z=0.35: alpha_cm_eff = -0.002
     - Real richness distribution, EACH CLUSTER'S OWN z: alpha_cm_eff =
       +0.032 to +0.068 — WRONG, discovered to entangle alpha_cm/beta_cm
       (mass derived from richness+beta_mr=-0.364 correlates mass with z
       by construction, corr=-0.36; using each cluster's own z folds
       colossus's direct z-dependence into an apparent mass-dependence).
     - Real richness distribution, z held FIXED (correct, isolates the
       mass slope the way the model defines alpha_cm): alpha_cm_eff =
       -0.041 (count-weighted, i.e. one vote per cluster).
     - CORRECT, FINAL number — user asked whether higher-mass clusters'
       stronger lensing signal was being accounted for; it wasn't.
       Weighting by each cluster's actual Fisher information on
       alpha_cm (using its real boost+floor-corrected covariance and
       the forward model's numerical derivative d(DeltaSigma)/d(alpha_cm),
       Eq. in the report below) instead of counting it once:
       alpha_cm_eff = +0.002 (essentially flat/zero). The top mass
       quintile (20% of the sample by count) carries 85% of the total
       Fisher information on alpha_cm — cluster count is a badly biased
       proxy for constraining power here.
   This Fisher-weighted number, ~0, sits close to the converged 6-bin
   fit's own combined posterior (+0.076 +0.075/-0.071) — the fitted
   result is not anomalous once compared against the right prediction.
   Full writeup with equations, derivations, and figures:
   `reports/2026-07-26_boost_factors_variance_floor_alpha_cm.tex` (PDF
   compiled, 11 pages) — covers the boost-factor fit/application, the
   variance floor, and this diemer19 section in detail. Not yet
   committed as of this writing.

   Outlier-count check requested 2026-07-25 (excluding ΔΣ ≤ 0 and ≥ 10000
   Msun/pc^2 as "wild outliers", from `gamma_scan_outputs/wazp_real_data`,
   n=15,967 clusters total, radii = logspace(-0.8, 0.6, 8) Mpc):
     bin 0  R=0.158 Mpc: finite 37.9%   clean(0<x<1e4) = 3,427  (21.5%)
     bin 1  R=0.251 Mpc: finite 66.2%   clean            = 6,302  (39.5%)
     bin 2  R=0.398 Mpc: finite 89.7%   clean            = 8,814  (55.2%)
     bin 3  R=0.631 Mpc: finite 98.4%   clean            = 9,739  (61.0%)  [old r_min_fit=0.5 cutoff]
     bin 4  R=1.000 Mpc: finite 99.4%   clean            = 9,990  (62.6%)
   Even far outside the "bad" zone, ~38-40% of clusters have per-cluster
   ΔΣ ≤ 0 at every radius (bins 4-7 plateau around 58-63% clean) — this is
   ordinary per-cluster shot noise (few background sources per
   cluster/annulus), not a defect specific to the inner bins. The inner
   bins are distinguished by LOW FINITE FRACTION (too few sources at all
   to even measure, positive or negative), not by an unusually high
   negative/outlier rate among the measurements that do exist.

3. **The WaZP cluster-finding algorithm produces a problematic sample** —
   e.g. miscentering, spurious detections, or richness-mass scatter
   properties that bias the recovered relation. **Not yet tested.**

**How to apply:** (1) is still an OPEN hypothesis, not ruled out — the
factor=1.1→1.2 test was confounded (see above) and the user does not
consider it settled. Don't claim foreground contamination has been
tested-and-rejected. If revisiting (1), a redshift-margin tightening
alone is not obviously the right lever given the confound above — think
about what would test it more cleanly (e.g. something that addresses the
joint fit's lack of boost correction, or inspects contamination directly
rather than via a margin sweep) before proposing another run. (2) and (3)
are not yet being actively worked — don't start investigating any of the
three unprompted; wait for the user's direction on what to try next.

**Artifacts from the (1) test**, kept on disk for reference (factor=1.1
baseline preserved throughout, nothing overwritten):
- `scripts/wazp_desy3_real_data_f1.2.yaml` / `wazp_desy3_inference_f1.2.yaml`
- `gamma_scan_outputs/wazp_real_data_f1.2/` (measurement, 15,925/15,967 usable)
- `gamma_scan_outputs/run_2026-07-24T14-12-22/` (joint fit, stopped at 3/50
  bootstraps by user request)
- `scripts/data/wazp_stacked_*_f1.2.pkl` (stacked cross-check, complete)
