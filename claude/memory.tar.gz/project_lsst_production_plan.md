---
name: lsst-production-plan
description: "DES-like conditions are information-poor; LSST-like is the production target, to be run on an external HPC cluster"
metadata: 
  node_type: memory
  type: project
  originSessionId: 16734ae6-b761-45b6-9a6a-da32b218c16b
---

As of 2026-07-15: the user considers DES-like conditions (7.5 gal/arcmin²) information-poor for the destacking γ measurement — the 2×2 diagnostic matrix showed miscalibration/bias there but clean, calibrated results in LSST-like conditions (40 gal/arcmin²). DES-like sampler failures (nautilus collapse at 15000 clusters) are therefore not a big worry.

**Why:** sets priorities — don't over-invest in fixing DES-density sampling; LSST-like scans are the production goal and will be run by the user on a proper HPC cluster, not on this machine.

**How to apply:** when preparing scan configs or code changes, optimize for the LSST-like HPC use case (config-file completeness, provenance, resumability, converged-flag gating). Local runs are for diagnostics. Related: [[metacal-response-sim-bug]].

Confirmed 2026-07-15: the nautilus collapse in DES-like 15000-cluster fits is geometry-driven, not timeout-driven — three fresh bootstrap fits with a 6000 s budget (10× the scan's) all failed to converge and collapsed onto the same γ≈+1.2–1.5 attractor with near-zero width. Do not revisit the timeout hypothesis; longer budgets alone cannot fix DES-density joint fits.
