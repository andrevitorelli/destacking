---
name: no-single-run-conclusions
description: Do not draw conclusions from single runs/draws — interpret only significant samples
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 16734ae6-b761-45b6-9a6a-da32b218c16b
---

Do not draw conclusions from single runs or individual bootstrap draws; either look at a statistically significant sample or don't interpret at all.

**Why:** During the DES Y3 γ-scan monitoring (July 2026), per-draw commentary ("bias firming up", "outlier suggests...") on each live bootstrap result amounted to over-interpreting noise — running means at 1-2σ wander in and out of significance draw by draw.

**How to apply:** When monitoring live per-bootstrap/per-run results, relay numbers without interpretation. Reserve statements about bias, error calibration, or modes for pre-agreed checkpoints with adequate N (e.g. the full bootstrap set), using proper aggregate statistics (mean ± error on mean, pull RMS). This applies at every level: individual bootstrap draws, single grid points of a scan, AND single failed/anomalous points — do not diagnose a whole run's configuration or recommend killing it from one or two grid points (reiterated 2026-07-12 after I did exactly that on the 11-γ scan). Relay the numbers, flag anomalies neutrally, wait for the sample. Related: [[min-stack-size-10]].
