---
name: wazp-desy3-alpha-cm-informative-prior
description: "Interim workaround for the WaZP+DES-Y3 alpha_cm anomaly: informative truncated-negative prior on alpha_cm in the joint fit, pending a proper boost-correction fix"
metadata:
  node_type: memory
  type: project
  originSessionId: 16734ae6-b761-45b6-9a6a-da32b218c16b
---

Given [[project_wazp_desy3_alpha_cm_anomaly]] and the inconclusive
factor=1.1→1.2 test in [[project_wazp_desy3_root_cause_hypotheses]], the
user's interim plan as of 2026-07-24 (while the real root cause is still
under investigation):

**Now:** impose an informative prior on `alpha_cm` in the joint fit
(`scripts/wazp_desy3_inference.yaml`) instead of the previous wide
unconstrained gaussian — `N(-0.1, 0.1)` truncated to `alpha_cm <= 0`,
reflecting the literature expectation (Dutton & Maccio 2014, Diemer &
Joyce 2019: mass-concentration slope is clearly negative) that the
unconstrained fit keeps failing to recover. This required generalizing
`gamma_inference.py`'s `_prior_from_spec`: any `fit_params.<name>` entry
with `prior: gaussian` can now take explicit `lo`/`hi` keys for one- or
two-sided truncation (previously this truncation mechanism was hardcoded
to only f_mis∈[0,1]/sigma_off≥0; those two keep working via the same
hardcoded fallback when lo/hi are omitted from their spec, so no existing
config's behaviour changed). Config: `alpha_cm: {fit: true, prior:
gaussian, loc: -0.1, scale: 0.1, hi: 0.0}`.

**Later (not yet started, user said "not now"):** fit the boost factor
from the stacked-cluster measurements (`wazp_stacked_analysis.py` already
computes per-stack `boosts`/`boosts_cov` via `xlensing.data.stacked_signal`)
and use that fitted boost model to correct the individual-cluster profiles
in the joint fit — the joint fit currently has NO boost correction at all
(`prepare_real_data.py` uses `bootstrap_signal`, not `single_cluster`, by
design, to match its boost-free NFW model). This is the more principled
fix under consideration; the informative prior above is a stopgap, not a
replacement for it.

**How to apply:** Don't start the boost-fitting work unprompted — the
user explicitly deferred it. If asked to help later, the natural home for
"fit boost(R) from stacked clusters, apply to individual-cluster ΔΣ" is
new code bridging `wazp_stacked_analysis.py`'s per-stack boost outputs
and `prepare_real_data.py`'s per-cluster measurement stage (or a
downstream correction step, since boost is stack-level and would need a
model to map onto individual clusters — richness/z/Δm-dependent
interpolation, most likely).
