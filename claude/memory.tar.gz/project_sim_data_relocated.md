---
name: sim-data-relocated
description: "destacking's notebooks/data/ and scripts/gamma_scan_outputs/ used to mix real WaZP+DES-Y3 data, simulated per-run outputs, and nautilus fit chains in-repo. Fully split 2026-07-27 into ~/destacking_data/{sims,real_data,output}/ on both develop and diemer_cm branches. All scripts/YAML/notebooks updated and functionally re-verified."
metadata:
  node_type: memory
  type: project
  originSessionId: 16734ae6-b761-45b6-9a6a-da32b218c16b
---

`destacking`'s in-repo data directories mixed real data, simulated-run
output, and inference-chain output together. Fully split into a three-way
external layout, same filesystem (`/dev/sdd`) as the repo so moves were
instant renames, not copies:

- **`~/destacking_data/sims/`** (~220GB) — simulated per-run outputs
  (`bgs.pkl`, `single_sigmas_*.npy`, etc.) and the one legacy full sim+
  inference run (`old_outputs/good_sim_test`).
- **`~/destacking_data/real_data/`** (~11GB) — real WaZP+DES-Y3 data
  (`wazp_*.fits`, `metacal_filtered.npz`) plus derived analysis products:
  boost fits, stacked/CMR/ML fits, bkg caches, and the 4
  `wazp_real_data*` measurement checkpoints (`prepare_real_data.py`'s
  `out_dir` / `gamma_inference.py`'s `data_folder`).
- **`~/destacking_data/output/`** (~9GB) — nautilus inference-only fit
  chains (`run_*` directories: bootstrap posteriors, corner plots, run
  summaries), all verified `simulation: false` via saved YAML config
  copies.

Classification rule for `_real_data.fits`/`_bgs.pkl`/`_metadata.json`-suffixed
files: NOT necessarily real — `destacking/io.py`'s `write_notebook_compat_sim`
uses that same on-disk layout for SIMULATED output too. Only `wazp_*`-prefixed
files (+ `metacal_filtered.npz`) are genuinely real.

**Code updated on both `develop` and `diemer_cm`** (mirror edits, since
`diemer_cm` has its own diverged copies of `gamma_inference.py`,
`prepare_real_data.py`, `real_data_config_example.yaml`,
`gamma_scan_replots.ipynb`, plus its own `gamma_inference_diemer.py` +
2 YAML configs):
- `RUN_DIR` default → `~/destacking_data/output/run_<ts>`
- `_NOTEBOOK_DATA_DIR` (sim notebook-compat output) → `~/destacking_data/sims`
- `filtered_cache`/`cluster_catalog_file`/`out_dir`/`data_folder`/`boosts`
  YAML keys → absolute `/home/andre/destacking_data/real_data/...` or
  `.../output/...` paths (YAML string values aren't `expanduser`-processed
  by the scripts, so `~` doesn't work there — must be a literal absolute
  path; Python code uses `os.path.expanduser` instead)
- `develop`-only additions with no `diemer_cm` counterpart, so only fixed
  once: `wazp_stacked_analysis.py`, all `wazp_desy3_*.yaml` configs, and
  the `wazp_desy3_*`/`wazp_stacked_plots`/boost-floor-combined-corner
  notebooks.
- Also carried the earlier (2026-07-27) `SIM_DATA_DIR` fix forward: three
  notebooks (`prototype_destacking.ipynb`, `wazp_lensing_signals.ipynb`,
  `wazp_mass_richness_by_delta_m.ipynb`) already point their `SIMS=True`
  branch at `~/destacking_data/sims` on `develop`; **not yet propagated to
  `diemer_cm`'s copies of those same three notebooks** (separate,
  lower-priority remaining gap — not part of the real_data/output task).

**Deliberately left alone**: ~8 dead debug scripts and 5 `hisnr_*.yaml`
configs reference specific historical `run_2026-0[5-7]-*` directories that
were already deleted from disk before this reorg — fixing their paths
would still leave them non-functional, not worth the effort.

**Verified functional**, not just syntax-checked: re-executed
`wazp_stacked_plots.ipynb` and `wazp_desy3_boost_floor6_combined_corner.ipynb`
end-to-end via `jupyter nbconvert --execute` against the new locations —
both ran clean, correct output confirmed.

**Committed and pushed 2026-07-27** on both `develop` (661ad26, then
merge commit 8414367) and `diemer_cm` (439deca), then `diemer_cm` merged
into both `claude` (clean fast-forward-equivalent merge, no conflicts —
`claude` had never diverged from the shared 29c5ef1 merge-base) and
`develop` (3 real conflicts in `gamma_inference.py`, `prepare_real_data.py`,
`notebooks/gamma_scan_replots.ipynb` — both branches had independently
applied the identical path fix today; resolved by keeping `develop`'s
side, which had the same fix plus fuller explanatory comments;
`real_data_config_example.yaml` auto-merged cleanly). All pushed to
`origin`.
