---
name: metacal-response-sim-bug
description: Sim injects unit-response shear but estimator divides by metacal response — all sim ΔΣ inflated ~18-22%
metadata: 
  node_type: memory
  type: project
  originSessionId: 16734ae6-b761-45b6-9a6a-da32b218c16b
---

Found 2026-07-11: in the destacking gamma_scan pipeline, `apply_triaxial_NFW_shear_region` (xlensing/sims.py) adds shear at full strength, but `_process_cluster` (scripts/gamma_scan.py) assigns metacal responses ⟨R⟩≈0.82 and the `signal()` estimator divides by (1+Mult.Bias)=Rt. Net effect: every simulated data vector is inflated by 1/⟨Rt⟩_w ≈ 1.18–1.22 relative to the model. Verified with a zero-shape-noise single-cluster test (flat +18% at 1–4 Mpc; sim/model shape functions agree to machine precision, rs/ρ/Σ_crit to 0.2%).

**Why:** invalidates the amplitude calibration of ALL simulation-based gamma-scan results before the fix; likely driver of the +0.14±0.04 γ bias and ~2.6× error underestimation seen in the 2026-07-10/11 v2 DES Y3 runs (triaxial and spherical control both affected).

**How to apply:** FIXED 2026-07-11: `apply_triaxial_NFW_shear_region` gained a `response=` parameter (per-galaxy shear scaling) and `_process_cluster` passes col-5 responses. Zero-noise verification: sim/model ratio 0.97-0.99 (residual −3% is bin-center vs annulus-average evaluation, known and benign). Any sim result predating 2026-07-11 still carries the +18-22% inflation — rerun, don't reuse. Related: [[no-single-run-conclusions]].
